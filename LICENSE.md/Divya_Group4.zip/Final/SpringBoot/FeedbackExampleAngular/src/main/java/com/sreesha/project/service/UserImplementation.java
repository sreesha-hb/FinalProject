package com.sreesha.project.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sreesha.project.model.User;
import com.sreesha.project.repo.UserRepo;

@Service
public class UserImplementation implements UserServiceInterface {
	
	@Autowired
	private UserRepo ur;

	public String saveUser(User user) {
		// TODO Auto-generated method stub
		user = ur.save(user);
		return user.getEmail();
	}

	public Optional<User> getUser(String email, String password) {
		// TODO Auto-generated method stub
		return ur.findById(email);
	}

	public List<User> getAllUser() {
		// TODO Auto-generated method stub
		return ur.findAll();
	}

	

}
