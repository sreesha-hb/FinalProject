package com.sreesha.project.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sreesha.project.model.User;

public interface UserRepo extends JpaRepository<User, String> {


}
