package com.sreesha.project.service;

import java.util.List;

import com.sreesha.project.model.Volunteer;

public interface VolunteerServiceInterface {
	
	public Integer saveVolunteer(Volunteer volunteer);
	List<Volunteer> getAllVolunteer();
	
}
