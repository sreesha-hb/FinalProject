package com.sreesha.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sreesha.project.model.FeedbackModel;
import com.sreesha.project.repo.FeedbackRepo;

@Service
public class FeedbackServiceImpl implements FeedbackServiceInterface {
	
	@Autowired
	private FeedbackRepo fr;

	public Integer saveFeedback(FeedbackModel fb) {
		// TODO Auto-generated method stub
		fb = fr.save(fb);
		return fb.getId();
	}

	public List<FeedbackModel> getAllFeedback() {
		// TODO Auto-generated method stub
		return fr.findAll();
	}

}
