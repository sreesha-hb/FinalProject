package com.sreesha.project.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sreesha.project.model.Medical;

public interface MedicalRepository extends JpaRepository<Medical, String> {

}
