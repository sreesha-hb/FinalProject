package com.sreesha.project.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sreesha.project.model.Admin;
import com.sreesha.project.repo.AdminRepository;

@Service
public class AdminServiceImpl implements AdminServiceInterface {
	
	@Autowired
	public AdminRepository ar;

	public Optional<Admin> getAdmin(String email, String password) {
		// TODO Auto-generated method stub
		return ar.findById(email);
	}

	

	

}
