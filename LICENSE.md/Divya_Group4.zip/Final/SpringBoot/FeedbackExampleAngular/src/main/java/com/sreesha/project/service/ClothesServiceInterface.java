package com.sreesha.project.service;

import java.util.List;

import com.sreesha.project.model.Clothes;

public interface ClothesServiceInterface {

	public Integer saveClothes(Clothes clothes);
	List<Clothes> getAllClothes();
	
}
