package com.sreesha.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sreesha.project.model.Donation;
import com.sreesha.project.repo.DonateRepository;

@Service
public class DonationServiceImpl implements DonationServiceInterface{

	@Autowired
	private DonateRepository repo;
	
	public Integer saveDonation(Donation donation) {
		// TODO Auto-generated method stub
		donation = repo.save(donation);
		return donation.getId();
	}

	public List<Donation> getAllDonation() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

}
