package com.sreesha.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sreesha.project.model.Clothes;
import com.sreesha.project.repo.ClothesRepository;

@Service
public class ClothesServiceImpl implements ClothesServiceInterface {

	@Autowired
	private ClothesRepository repo;
	
	
	public Integer saveClothes(Clothes clothes) {
		clothes = repo.save(clothes);
		return clothes.getId();
	}


	public List<Clothes> getAllClothes() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

}
