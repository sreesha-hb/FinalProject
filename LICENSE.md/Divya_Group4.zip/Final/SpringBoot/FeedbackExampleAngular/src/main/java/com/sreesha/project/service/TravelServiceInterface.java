package com.sreesha.project.service;

import java.util.List;

import com.sreesha.project.model.Travel;

public interface TravelServiceInterface {
	
	public String saveTravel(Travel travel);
	List<Travel> getAllTravel();

}
