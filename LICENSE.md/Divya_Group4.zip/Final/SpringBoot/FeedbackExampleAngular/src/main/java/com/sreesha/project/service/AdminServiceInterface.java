package com.sreesha.project.service;

import java.util.Optional;

import com.sreesha.project.model.Admin;

public interface AdminServiceInterface {

	Optional<Admin> getAdmin(String email, String password);
}
