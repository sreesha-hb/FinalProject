import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Feedback } from './feedback';
import { Volunteer } from './volunteer';
import { User } from './user';
import { Food } from './food';
import { Clothes } from './clothes';
import { Medical } from './medical';
import { Travel } from './travel';
import { Admin } from './admin';
import { Donation } from './donation';




@Injectable({
   providedIn: 'root',
})

export class AdminServices {
   Admindisplay() {
     throw new Error('Method not implemented.');
   }
   private basePath= "http://localhost:8091/rest/feedback";

   constructor(private http: HttpClient) {}

   
 getAllStudents(): Observable<Food[]> {
    return this.http.get<Food[]>(`${this.basePath}/getFood`);
  }

  getAllMedicine(): Observable<Medical[]> {
    return this.http.get<Medical[]>(`${this.basePath}/getMedical`);
  }

  getAllTravel(): Observable<Travel[]> {
    return this.http.get<Travel[]>(`${this.basePath}/getTravel`);

  }
   getAllDonation(): Observable<Donation[]> {
    return this.http.get<Donation[]>(`${this.basePath}/getDonation`);

   }
   getAllVolunteer(): Observable<Volunteer[]> {
    return this.http.get<Volunteer[]>(`${this.basePath}/getVolunteer`);

   }
   getAllClothes(): Observable<Clothes[]> {
    return this.http.get<Clothes[]>(`${this.basePath}/getClothes`);

   }
   getAllFeedback(): Observable<Feedback[]> {
    return this.http.get<Feedback[]>(`${this.basePath}/getFeedback`);

   }
   getAllUser(): Observable<User[]> {
     return this.http.get<User[]>(`${this.basePath}/getUser`);
   }
   
}