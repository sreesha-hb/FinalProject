import { Component, OnInit } from '@angular/core';
import { Food } from './../food';
import { Clothes } from '../clothes';
import { Travel } from '../travel';
import { Medical } from './../medical';
import { Donation } from '../donation';
import { Volunteer } from '../volunteer';
import { Feedback } from './../feedback';
import { User } from './../user';
import { AdminServices } from './../admin.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  food1!: Food[];
  clothes!: Clothes[];
  travel!: Travel[];
  medicine1!: Medical[];
  donation!:Donation[];
  volunteer!:Volunteer[];
  feedback1!:Feedback[];
  user!: User[];

  constructor(private service: AdminServices ,private http: HttpClient) {  }

  ngOnInit(): void {
    this.getAllStudents();
    this.getAllClothes();
    this.getAllTravel();
    this.getAllMedicine();
    this.getAllDonation();
    this.getAllVolunteer();
    this.getAllFeedback();
    this.getAllUser();
  }

  getAllStudents() {
    return this.service.getAllStudents()
    .subscribe(
      data => {
        this.food1 = data;
      }, error => {
        console.log(error);
      }
    );
  }

  getAllClothes() {
    return this.service.getAllClothes()
    .subscribe(
      data => {
        this.clothes = data;
      }, error => {
        console.log(error);
      }
    );
  }

  getAllTravel() {
    return this.service.getAllTravel()
    .subscribe(
      data => {
        this.travel = data;
      }, error => {
        console.log(error);
      }
    );
  }  

  getAllMedicine() {
    return this.service.getAllMedicine()
    .subscribe(
      data => {
        this.medicine1 = data;
      }, error => {
        console.log(error);
      }
    );
  }

  getAllDonation() {
    return this.service.getAllDonation()
    .subscribe(
      data => {
        this.donation = data;
      }, error => {
        console.log(error);
      }
    );
  }

  getAllVolunteer() {
    return this.service.getAllVolunteer()
    .subscribe(
      data => {
        this.volunteer = data;
      }, error => {
        console.log(error);
      }
    );
  }

  getAllFeedback() {
    return this.service.getAllFeedback()
    .subscribe(
      data => {
        this.feedback1 = data;
      }, error => {
        console.log(error);
      }
    );
  }

  getAllUser() {
    return this.service.getAllUser()
    .subscribe(
      data => {
        this.user = data;
      }, error => {
        console.log(error);
      }
    );
  }

}
