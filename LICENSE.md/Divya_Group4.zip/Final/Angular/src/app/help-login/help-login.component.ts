import { Component, OnInit } from '@angular/core';
import { FeedbackServices } from './../feedback.service';
import { User } from './../user'; 
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';

@Component({
  selector: 'app-help-login',
  templateUrl: './help-login.component.html',
  styleUrls: ['./help-login.component.css']
})
export class HelpLoginComponent implements OnInit {

  user!: User;
  login!: User;
  message!: string;

  constructor(private service: FeedbackServices, private sb: MatSnackBar, private router: Router) { }

  ngOnInit(): void {
    this.user = new User();
    this.login = new User();
  }

  regUser() {
    this.service.regUser(this.user).subscribe(
      data => {this.user = new User(); this.message = data; this.sb.open(data.toString(), "Dismiss");}, error => {console.log(error)}
    );
  }

  loginUser(email: string, password: string) {
    this.service.getUser(email, password).subscribe(
      data => {this.message = data; this.sb.open(data.toString(), "Dismiss"); if (data.toString()=='true') {this.router.navigate(['help', email]), this.sb.open("Welcome "+email, "Dismiss")};} , 
      error => {this.message = error; this.sb.open("Account Not Found", "Dismiss")}
    );
  }
 
}
