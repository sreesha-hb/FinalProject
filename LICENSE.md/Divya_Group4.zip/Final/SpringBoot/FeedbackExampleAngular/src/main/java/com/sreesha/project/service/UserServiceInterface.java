package com.sreesha.project.service;

import java.util.List;
import java.util.Optional;

import com.sreesha.project.model.User;

public interface UserServiceInterface {

	public String saveUser(User user);
	
	Optional<User> getUser(String email, String password);
	List<User> getAllUser();
}
