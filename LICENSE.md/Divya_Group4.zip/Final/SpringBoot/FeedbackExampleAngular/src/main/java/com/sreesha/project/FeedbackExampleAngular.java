package com.sreesha.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeedbackExampleAngular {
	public static void main(String[] args) {
		SpringApplication.run(FeedbackExampleAngular.class, args);
	}
}
