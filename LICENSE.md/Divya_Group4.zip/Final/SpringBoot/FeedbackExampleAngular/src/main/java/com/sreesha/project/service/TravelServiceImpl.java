package com.sreesha.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sreesha.project.model.Travel;
import com.sreesha.project.repo.TravelRepository;

@Service
public class TravelServiceImpl implements TravelServiceInterface {

	@Autowired
	private TravelRepository repo;
	
	public String saveTravel(Travel travel) {
		// TODO Auto-generated method stub
		travel = repo.save(travel);
		return travel.getEmail();
	}

	public List<Travel> getAllTravel() {
		return repo.findAll();
	}

}
