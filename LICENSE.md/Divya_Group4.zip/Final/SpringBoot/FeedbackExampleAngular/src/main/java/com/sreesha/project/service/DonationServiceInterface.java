package com.sreesha.project.service;

import java.util.List;

import com.sreesha.project.model.Donation;

public interface DonationServiceInterface {

	public Integer saveDonation(Donation donation);
	List<Donation> getAllDonation();
}
