package com.sreesha.project.service;

import java.util.List;

import com.sreesha.project.model.Medical;

public interface MedicalServiceInterface {

	public Integer saveMedical(Medical medical);
	List<Medical> getAllMedicine();
	
}
