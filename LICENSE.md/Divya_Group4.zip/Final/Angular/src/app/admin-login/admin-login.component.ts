import { Component, OnInit } from '@angular/core';
import { Admin } from './../admin';
import { FeedbackServices } from './../feedback.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {

  admin!: Admin;
  message!: string;


  constructor(private service: FeedbackServices, private sb: MatSnackBar, private router: Router) { }

  ngOnInit(): void {
    this.admin = new Admin();
  }

  loginAdmin(email: string, password: string) {
    this.service.loginAdmin(email, password).subscribe(
      data => {this.message = data; this.sb.open(data.toString(), "Dismiss"); if (data.toString()=='true') {this.router.navigate(['admin', email]), this.sb.open("Welcome "+email, "Dismiss")};},
      error => {this.message = error;}
    );
  }

}
