package com.sreesha.project.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sreesha.project.model.Travel;

public interface TravelRepository extends JpaRepository<Travel, String> {

}
