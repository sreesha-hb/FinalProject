import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FeedbackComponent } from './feedback/feedback.component';
import { HomeComponent } from './home/home.component';
import { VolunteerComponent } from './volunteer/volunteer.component';
import { HelpLoginComponent } from './help-login/help-login.component';
import { HelpComponent } from './help/help.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminComponent } from './admin/admin.component';

const routes: Routes = [
  {path: 'home', component: HomeComponent },
  {path: 'feedback', component: FeedbackComponent },
  {path: 'volunteer', component: VolunteerComponent },
  {path: 'help-login', component: HelpLoginComponent },
  {path: 'help/:email', component: HelpComponent },
  {path: 'admin-login', component: AdminLoginComponent },
  {path: 'admin/:email', component: AdminComponent },
  {path: '', redirectTo: 'home', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
