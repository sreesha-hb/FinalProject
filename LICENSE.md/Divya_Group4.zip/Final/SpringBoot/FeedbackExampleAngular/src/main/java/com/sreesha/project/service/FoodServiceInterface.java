package com.sreesha.project.service;

import java.util.List;

import com.sreesha.project.model.Food;

public interface FoodServiceInterface {
	public Integer saveFood(Food food);
	List<Food> getAllFood();
}
